import pyautogui, random, time, keyboard, threading, tkinter as tk, os, configparser, sys
from tkinter import colorchooser

pyautogui.FAILSAFE = True

def resource_path(relative):
    try: base = sys._MEIPASS
    except: base = os.path.abspath(".")
    return os.path.join(base, relative)

config_file = resource_path("config.cfg")
config = configparser.ConfigParser()

default_settings = {
    "coords": str([(1069,528),(1111,528)]), # Coordinates where the macro will click, check FAQ for more information on this.
    "cycles":"15", # How many times the macro will activate until taking a break.
    "move_min":"0.05", 
    "move_max":"0.15", 
    "click_min":"0.3", 
    "click_max":"0.8", 
    "wait_min":"15", # Break in seconds.
    "wait_max":"25",
    "bg_color":"#1e1e1e", 
    "fg_color":"#ffffff",
    "button_color":"#2d2d2d",
    "running_color":"#00ff88",
    "stopped_color":"#ff5555",
}

if not os.path.exists(config_file):
    config["Settings"] = default_settings
    with open(config_file,"w") as f: config.write(f)
config.read(config_file)

settings = {
    "coords": eval(config["Settings"]["coords"]),
    "cycles": int(config["Settings"]["cycles"]),
    "move_min": float(config["Settings"]["move_min"]),
    "move_max": float(config["Settings"]["move_max"]),
    "click_min": float(config["Settings"]["click_min"]),
    "click_max": float(config["Settings"]["click_max"]),
    "wait_min": float(config["Settings"]["wait_min"]),
    "wait_max": float(config["Settings"]["wait_max"])
}

colors = {
    "bg": config["Settings"]["bg_color"],
    "fg": config["Settings"]["fg_color"],
    "button": config["Settings"]["button_color"],
    "running": config["Settings"]["running_color"],
    "stopped": config["Settings"]["stopped_color"]
}

running = False
def click_loop():
    global running
    while True:
        if not running: time.sleep(0.1); continue
        for _ in range(settings["cycles"]):
            if not running: break
            random.shuffle(settings["coords"])
            for x,y in settings["coords"]:
                if not running: break
                pyautogui.moveTo(x,y,duration=random.uniform(settings["move_min"],settings["move_max"]))
                pyautogui.click()
                time.sleep(random.uniform(settings["click_min"],settings["click_max"]))
        wait_time = random.uniform(settings["wait_min"],settings["wait_max"])
        for _ in range(int(wait_time*10)):
            if not running: break
            time.sleep(0.1)

def start_clicking(): 
    global running
    running=True
    status_label.config(text="Running",fg=colors["running"])
def stop_clicking():
    global running
    running=False
    status_label.config(text="Stopped",fg=colors["stopped"])
keyboard.add_hotkey("F5",start_clicking) # Change ur hotkeys over here
keyboard.add_hotkey("F6",stop_clicking)

root = tk.Tk()
root.title("AutoOrder Dropper")
root.geometry("280x400") # Change this to make the menu bigger/smaller
root.attributes("-topmost", True)
root.configure(bg=colors["bg"])
root.iconbitmap(resource_path("icon.ico"))

status_label = tk.Label(root,text="Ready",font=("Segoe UI",14,"bold"),fg=colors["stopped"],bg=colors["bg"])
status_label.pack(pady=10)

def apply_theme():
    root.configure(bg=colors["bg"])
    for w in root.winfo_children():
        try: w.configure(bg=colors["bg"],fg=colors["fg"])
        except: pass

def pick_color(key):
    c = colorchooser.askcolor(colors[key])[1]
    if c:
        colors[key]=c
        apply_theme()
        save_settings()

def add_entry(label,key):
    tk.Label(root,text=label).pack()
    var=tk.StringVar(value=str(settings[key]))
    entry=tk.Entry(root,textvariable=var)
    entry.pack()
    def update(*_):
        try: settings[key]=float(var.get()) if "." in var.get() else int(var.get()); save_settings()
        except: pass
    var.trace_add("write",update)

def save_settings():
    config["Settings"]["coords"]=str(settings["coords"])
    config["Settings"]["cycles"]=str(settings["cycles"])
    config["Settings"]["move_min"]=str(settings["move_min"])
    config["Settings"]["move_max"]=str(settings["move_max"])
    config["Settings"]["click_min"]=str(settings["click_min"])
    config["Settings"]["click_max"]=str(settings["click_max"])
    config["Settings"]["wait_min"]=str(settings["wait_min"])
    config["Settings"]["wait_max"]=str(settings["wait_max"])
    config["Settings"]["bg_color"]=colors["bg"]
    config["Settings"]["fg_color"]=colors["fg"]
    config["Settings"]["button_color"]=colors["button"]
    config["Settings"]["running_color"]=colors["running"]
    config["Settings"]["stopped_color"]=colors["stopped"]
    with open(config_file,"w") as f: config.write(f)

add_entry("Cycles per run","cycles")
add_entry("Move min (s)","move_min")
add_entry("Move max (s)","move_max")
add_entry("Click min (s)","click_min")
add_entry("Click max (s)","click_max")
add_entry("Wait min (s)","wait_min")
add_entry("Wait max (s)","wait_max")

tk.Label(root,text="F5 = Start   |   F6 = Stop").pack(pady=10)
apply_theme()

threading.Thread(target=click_loop,daemon=True).start()
root.mainloop()
